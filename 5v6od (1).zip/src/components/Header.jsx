import React from"react";

function Header(){
  return(
    <header>
      <h1> shapeal Bootcamp</h1>
    </header>
  );
}
export default Header;