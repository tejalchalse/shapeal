import React from "react";

function info(){
  return(
    <div className="note">
      <h1>Javascript and reacts.js</h1>
      <p>Basics web development reacts js bootcamp</p>
      </div>
  );
}
export default info;
