import React from"react";

function footer(){
  return(
    <footer>
      <p>Copyright By Shapeal@{new Date().getFullYear()}
      </p> 
    </footer>
  );
}
export default footer;
